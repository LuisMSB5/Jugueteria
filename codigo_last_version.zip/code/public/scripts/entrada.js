//Agregando las variables para usar para realizar la animacion

const contenerdo = document.querySelector(".content");

const titulo1 = document.querySelector(".hero__title");
const titulo2 = document.querySelector(".hero__image");
const cubo1 = document.querySelector("#cube1");
const cubo2 = document.querySelector("#cube2");
const cubo3 = document.querySelector("#cube3");
const cubo4 = document.querySelector("#cube4");
const cubo5 = document.querySelector("#cube5");
const cubo6 = document.querySelector("#cube6");
const cubo7 = document.querySelector("#cube7");
const cubo8 = document.querySelector("#cube8");

contenerdo.style.display = "none";

titulo1.style.display = "block";
titulo2.style.display = "block";

setTimeout(ocultar, 15000);

function ocultar(){

    titulo1.style.display = "none";
    titulo2.style.display = "none";
    contenerdo.style.display = "block";

    cubo1.style.display = "none";
    cubo2.style.display = "none";
    cubo3.style.display = "none";
    cubo4.style.display = "none";
    cubo5.style.display = "none";
    cubo6.style.display = "none";
    cubo7.style.display = "none";
    cubo8.style.display = "none";

}
