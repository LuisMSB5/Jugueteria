
//accion de varios botones
const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const mysql = require('mysql2');

const app = express();
const PORT = 3000;


// Servir archivos estáticos desde la carpeta 'public'
app.use(express.static(path.join(__dirname, '../public')));

// Middleware para parsear el cuerpo de las solicitudes
app.use(bodyParser.urlencoded({ extended: true }));



//conectar a la base de datos mysql
const connection = mysql.createConnection({

    host: "localhost",
    user: "root",
    password: "",
    database: "jugueteria"

});

connection.connect(error => {

    if (error){

        console.log("Error en la conexion de la base de datos");
        return;

    }

    console.log("Conexion a la base de datos de manera exitosa");

});

//obteniendo todos los datos de la base de datos para mostrarlo en el app.get

let mensaje_cliente = ''; // Mensaje para mostrar en la salida web, contiene los datos de la base de datos de la tabla cliente
let mensaje_productos = ''; // Mensaje para mostrar en la salida web, contiene los datos de la base de datos de la tabla productos 
let mensaje_categorias = ''; // Mensaje para mostrar en la salida web, contiene los datos de la base de datos de la tabla categorias
let mensaje_ventas = ''; // Mensaje para mostrar en la salida web, contiene los datos de la base de datos de la tabla Ventas

//llenando la variable de almacenaje de la tabla cliente
    const query = "SELECT * FROM clientes_datos";
    connection.query(query, (err, result) => {
        
        if (err) {
            console.error(err);
        } 
        
        else {

            for (var x = 0; x < result.length; x++) {
                mensaje_cliente += `<tr><td>${result[x].codigo_cliente}</td> <td>${result[x].nombre_cliente}</td> <td>${result[x].apellido_cliente}</td> <td>${result[x].telefono_cliente}</td> <td>${result[0].email_cliente}</td></tr>`;
            }
        }
    });

        
    //llenando la variable de almacenaje de la tabla cliente
    const query2 = "SELECT * FROM productos";
    connection.query(query2, (err, result) => {
        
        if (err) {
            console.error(err);
        } 
        
        else {

            for (var x = 0; x < result.length; x++) {
                mensaje_productos += `<tr><td>${result[x].codigo_producto}</td> <td>${result[x].nombre_producto}</td> <td>${result[x].codigo_categoria}</td> <td>${result[x].cantidad_producto}</td> <td>${result[x].precio_producto}</td></tr>`;
            }

        }
    });


    //llenando la variable de almacenaje de la tabla cliente
    const query3 = "SELECT * FROM categorias";
    connection.query(query3, (err, result) => {
        
        if (err) {
            console.error(err);
        } 
        
        else {

            for (var x = 0; x < result.length; x++) {
                mensaje_categorias += `<tr><td>${result[x].codigo_categoria}</td> <td>${result[x].nombre_categoria}</td> <td>${result[x].descripcion_categoria}</td></tr>`;
            }

        }
    });


    //llenando la variable de almacenaje de la tabla cliente
    const query4 = "SELECT * FROM venta";
    connection.query(query4, (err, result) => {
        
        if (err) {
            console.error(err);
        } 
        
        else {

            for (var x = 0; x < result.length; x++) {
                mensaje_ventas += `<tr><td>${result[x].numero_venta}</td> <td>${result[x].codigo_cliente}</td> <td>${result[x].codigo_producto}</td> <td>${result[x].cantidad_venta}</td> <td>${result[x].fecha_venta}</td> <td>${result[x].total_venta}</td></tr>`;
            }

        }
    });




//dando salida al codigo html para mostrarlo en la web
app.get("/", (req, res) => {
   

    res.send(`
        
        <!DOCTYPE html>
        <html lang="en">
        <head>
            
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Jugueteria</title>
            <link rel="stylesheet" href="/styles/clientes.css">
            <link rel="stylesheet" href="/styles/productos.css">
            <link rel="stylesheet" href="/styles/categorias.css">
            <link rel="stylesheet" href="/styles/ventas.css">
            <link rel="stylesheet" href="/styles/entrada.css">
    <link rel="shortcut icon" href="/logo.ico" type="image/x-icon">

        </head>

        <body>


            <!-- Animacion de entrada de el participante de la tesis -->
            <div class="hero"> 
            
                <div class="hero__title"> CHICO DE LOS ARMABLES </div>
                <img src="/imagen.png" class ="hero__image">

                <div class="cube" id = "cube1"></div>
                <div class="cube" id = "cube2"></div>
                <div class="cube" id = "cube3"></div>
                <div class="cube" id = "cube4"></div>
                <div class="cube" id = "cube5"></div>
                <div class="cube" id = "cube6"></div>
                <div class="cube" id = "cube7"></div>
                <div class="cube" id = "cube8"></div>
            
            <div/div>

            <!-- parte del fondo -->
            <div class="bg"></div>
            <div class="bg bg2"></div>
            <div class="bg bg3"></div>
            
            <!-- Contenedor para el fondo en movimiento que se vera -->
            <div class="content">

                <nav>

                    <!-- Estos botons cuando tenga el curso encima el texto cambiara a modificar
                    y cuando se presione 2 veces, este cambiara el tipo de la web-->

                    <p id="blue" class="clientes">Clientes</p>
                    <p id="green" class="productos">Productos</p>
                    <p id="yellow" class="categorias">Categorias</p>
                    <p id="red" class="ventas">Ventas</p>

                </nav>

                <!-- El Formulario contendra dentro suyo todos los elementos que se mostrara variando el boton que se presione de parte del nav-->
                <form action="/submit" method="POST" class = "formulario">

                    <div class="clientes_visualizar">        
                        <table border="1">

                            <tr>
                                <td>Codigo</td> <td>Nombre</td> <td>Apellido</td> <td>Telefono</td> <td>Email</td>
                            </tr>

                            ${mensaje_cliente}

                        </table>
                    </div>

                    <!-- Clientes modificar -->
                    <div class="clientes_modificar">

                        <div class="columns">

                            <div>
                                <p>Codigo</p> <input type="text" id="numero" name="codigo_cliente">
                            </div>
                        
                                        
                            <div>
                                <p>Nombre</p> <input type="text" id="numero" name="nombre_cliente">
                            </div>
                                        
                            <div>
                                <p>Apellido</p> <input type="text" id="numero" name="apellido_cliente">
                            </div>

                        </div>
                    
                                
                        <div class="columns2">
                            <div>
                                <p>Email</p> <input type="email" id="numero" name="email_cliente">
                            </div>

                            <div>
                                <p>Telefono</p> <input type="text" id="numero" name="telefono_cliente">
                            </div>
                        </div>

                        <div class="buttons">
                            <button type="submit" name="clientes" value="eliminar">Eliminar</button> <button type="submit" name="clientes" value="guardar">Guardar</button>
                        </div>
                                
                    </div>
                    

                    <!-- Productos visualizar -->
                    <div class="productos_visualizar">

                        <table>

                            <tr>
                                <td>codigo</td> <td>Nombre</td> <td>Categoria</td> <td>Cantidad</td> <td>Precio</td>
                            </tr>

                            ${mensaje_productos}

                        </table>

                    </div>


                    <!-- Productos modificar -->
                    <div class="productos_modificar">

                        <div class="columns1">

                            <div><p>Codigo</p> <input type="text" name="codigo_productos"></div>
                            <div><p>Nombre</p> <input type="text" name="nombre_productos"></div>
                            <div><p>Codigo de Categoria</p> <input type="text" name="categoria_productos"></div>

                        </div>

                        <div class="columns2">

                            <div><p>Cantidad</p> <input type="text" name="cantidad_productos"></div>
                            <div><p>Precio</p> <input type="text" name="precio_productos"></div>

                        </div>

                        <div class="buttons">
                            <button type="submit" name="productos" value="eliminar">Eliminar</button> <button type="submit" name="productos" value="guardar">Guardar</button>
                        </div>

                    </div>



                    <!-- Categorias visualizar -->

                    <div class="categoria_visualizar">
                        
                        <table>

                            <tr>
                                <td>Codigo</td> <td>Nombre</td> <td>Descripcion</td>
                            </tr>

                            ${mensaje_categorias}

                        </table>

                    </div>

                    
                    
                    <!--Categoria Modificar -->
                    <div class="categoria_modificar">

                        <div class="column1">
                            <div> <p>Codigo de Categoria</p> <input type="text" name="codigo_categoria"></div>
                            <div> <p>Nombre de Categoria</p> <input type="text" name="nombre_categoria"></div>
                        </div>

                        <div class="column2">
                            <p>Descripcion de la Categoria</p> <textarea name="descripcion_categoria"></textarea>
                        </div>

                        <div class="buttons">
                            <button type="submit" name="categorias" value="eliminar">Eliminar</button> <button type="submit" name="categorias" value="guardar">Guardar</button>
                        </div>

                    </div>
                    
                    <!-- Ventas visualizar -->

                    <div class="ventas_visualizar">

                        <table>

                            <tr>

                                <td>Numero venta</td> <td>Codigo Cliente</td> <td>Productos de la compra</td> <td>Cantidad de productos</td> <td>Fecha</td> <td>Costo total</td>

                            </tr>

                            ${mensaje_ventas}

                        </table>

                    </div>
                    
                    

                    <!-- Ventas modificar -->
                    <div class="ventas_modificar">

                        <div class="column1">

                            <div>
                                <p>Fecha de la venta</p> <input type="date" name="fecha_venta">
                            </div>
                            
                            <div>
                                <p>Codigo del Cliente</p> <input type="text" name="cliente_venta">
                            </div>   

                            <div>
                                <p>Producto</p> <input type="text" name="producto_venta" id="">
                            </div>
                                
                            <div>
                                <p>Cantidad</p> <input name="cantidad_venta">
                            </div>
                            
                        </div>

                        
                        <div class="costo_total">
                            <p>Costo total</p> <input type="text" name="costo_venta" id="">
                        </div>
                
                        <div class="buttons">
                            <button type="submit" name="ventas" value="eliminar">Eliminar</button> <button type="submit" name="ventas" value="guardar">Guardar</button>
                        </div>

                        
                    </div>

                </form>

            <!-- Final de el div content para el fondo -->

            </div>
            
        </body>

        <!-- Scripts de javascript -->
        <script src="scripts/cambio_pantalla.js"></script>
        <script src="scripts/entrada.js"></script>

        </html>
        
        `);

        

});

//herramientas para que la web funcione correctamente



// Manejar la solicitud POST del formulario
app.post('/submit', (req, res) => {

    //datos del formulario de clientes
    const { codigo_cliente, nombre_cliente, apellido_cliente, email_cliente, telefono_cliente, clientes } = req.body;

    //condicion de clientes
    switch (clientes) {
        case 'guardar':
            res.send(`<h1 style = 'text-align: center; margin-top: 25%;'> Enviado con exito </h1>`);
            const agregar = connection.execute(`insert into clientes_datos(codigo_cliente, nombre_cliente, apellido_cliente, telefono_cliente, email_cliente) value ("${codigo_cliente}", "${nombre_cliente}", "${apellido_cliente}", "${email_cliente}", "${telefono_cliente}");`);
            break;
     
     
        case 'eliminar':
            res.send(`<h1 style = 'text-align: center; margin-top: 25%;'> Eliminado con exito </h1>`);
            const eliminar = connection.execute(`DELETE FROM clientes_datos WHERE codigo_cliente = '${codigo_cliente}';`);
            console.log(codigo_cliente + "Eliminado con exito");
            break;
    }
    
    //datos del formulario de productos
    const { codigo_productos, nombre_productos, categoria_productos, cantidad_productos, precio_productos, productos } = req.body;

    //condicion de productos
    switch (productos) {
        case 'guardar':
            res.send(`<h1 style = 'text-align: center; margin-top: 25%;'> Enviado con exito </h1>`);
            const agregar = connection.execute(`insert into productos (codigo_producto, nombre_producto, codigo_categoria, cantidad_producto, precio_producto) value ( '${codigo_productos}', '${nombre_productos}', '${categoria_productos}', ${cantidad_productos}, ${precio_productos} );`);
            break;

        case 'eliminar':
            res.send(`<h1 style = 'text-align: center; margin-top: 25%;'> Eliminado con exito </h1>`);
            const eliminar = connection.execute(`DELETE FROM productos WHERE codigo_producto = '${codigo_productos}';`);
            break;
    }


    //datos de categorias

    const { codigo_categoria, nombre_categoria, descripcion_categoria, categorias } = req.body;

    //condicion de categorias
    switch(categorias){
        case "guardar":
            res.send(`<h1 style = 'text-align: center; margin-top: 25%;'> Enviado con exito </h1>`);
            const agregar = connection.execute(`insert into categorias (codigo_categoria, nombre_categoria, descripcion_categoria) value ('${codigo_categoria}', '${nombre_categoria}', '${descripcion_categoria}');`);
            break;

        case 'eliminar':
            res.send(`<h1 style = 'text-align: center; margin-top: 25%;'> Eliminado con exito </h1>`);
            const eliminar = connection.execute(`DELETE FROM categorias WHERE codigo_categoria = '${codigo_categoria}';`);
            break;

    }


    //datos de el formulario de ventas
    const { fecha_venta, cliente_venta, producto_venta, cantidad_venta, costo_venta, ventas } = req.body;

    //condiciones de ventas
    switch(ventas){
        case "guardar":
            res.send(`<h1 style = 'text-align: center; margin-top: 25%;'> Enviado con exito </h1>`);
            const query = connection.execute(`insert into venta (codigo_cliente, codigo_producto, cantidad_venta, fecha_venta, total_venta) value ('${cliente_venta}', '${producto_venta}', ${cantidad_venta}, '${fecha_venta}', ${costo_venta});`);
            break;

        case 'eliminar':
            res.send(`<h1 style = 'text-align: center; margin-top: 25%;'> Eliminados con exito </h1>`);
            break;

    }

});


// Iniciar el servidor
app.listen(PORT, () => {
    console.log(`Servidor escuchando en http://localhost:${PORT}`);
});
